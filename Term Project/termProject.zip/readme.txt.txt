Ezzy World is a Python (Tkinter-based) game. No extra modules are needed
to run the game. Simply run the program through a Python-compatible
program runner (ex: IDLE, Sublime, Visual Studios, etc.). This game
is a type of life-simulating game just like The Sims or Tamagotchi.
Enjoy the game! :)

To run, run the file "Ezzy World.py"