 #Ezzy World

from eventBasedAnimationClass import EventBasedAnimationClass
from Tkinter import *
import random
import time


class runGame(EventBasedAnimationClass):
    def __init__(self):
        super(runGame, self).__init__(800, 600)

    def initAnimation(self):
        self.Ezzies = []
        self.create = False
        self.help = False
        self.drawCreateEzzy()
        self.root.bind("<Motion>", lambda event: self.onMousePressedWrapper(self.motion))

    def createObj(self):
        newEzzy = Ezzy(self.width, self.height)
        self.Ezzies.append(newEzzy)
        print self.Ezzies

    def helpScreen(self):
        if self.help == True:
            self.drawHelp()

    def drawHelp(self):
        self.canvas.create_rectangle(0,0,800,600,fill="peach puff")
        self.canvas.create_text(self.width/2, 100, text="Instructions: TBD")

    def onKeyPressed(self, event):
        ezzy = self.Ezzies[0]
        if event.char == "h":
            if self.help == False: self.help = True
            elif self.help == True: self.help = False
        
    def onMousePressed(self, event):
        if (event.x > 0 and event.x < 50 and event.y > 0 and
            event.y < 50):
            if len(self.Ezzies) == 0:
                self.createObj()
        elif (len(self.Ezzies) == 1 and event.x > 0 and event.y > 0 and
              event.x < self.width and event.y < self.height):
            self.drawMotion(event.x, event.y)

    def createEzzy(self):
        pass

    def onTimerFired(self):
        if self.Ezzies != []:
            ezzy = self.Ezzies[0]
            if ezzy.happiness > 1:
                ezzy.happiness -= 1
            ezzy.changeMood()
    
    def redrawAll(self):
        self.canvas.delete(ALL)
        
        self.canvas.create_rectangle(0,0,self.width,self.height,
                                     fill="white")
        if self.help == True: self.drawHelp()
        else: self.canvas.delete(ALL)
        for i in xrange(len(self.Ezzies)):
            self.Ezzies[i].drawEzzy(self.canvas)
        self.drawCreateEzzy()
        self.drawMenu()

    def drawCreateEzzy(self):
        self.button = PhotoImage(file="button.gif")
        self.canvas.create_image(25,0, anchor = "n", image = self.button)

    def drawMenu(self):
        self.menu = PhotoImage(file="menubutton.gif")
        self.canvas.create_image(75, 0, anchor='n', image=self.menu)

    def drawMotion(self, x, y):
        ezzy = self.Ezzies[0]
        ezzy.moveEzzy(x, y)
        for i in xrange(10):
            ezzy.x += ezzy.xfactor
            ezzy.y += ezzy.yfactor
            if ezzy.motion == 0: ezzy.motion = 1
            elif ezzy.motion == 1: ezzy.motion = 0
            ezzy.drawEzzy(self.canvas)
            self.canvas.after(150)
            self.canvas.update()

class Ezzy(object):
    def __init__(self, x, y, happiness = 100):
        self.moods = [("TP-1.1.gif","TP-1.1.1.gif"), ("TP-1.2.gif","TP-1.2.1.gif"),
                      ("TP-1.3.gif", "TP-1.3.1.gif")]
        self.moodindex = 0
        #add characteristics of person here
        self.x, self.y = x/2, y/2
        self.happiness = happiness
        self.age = 0 #determines movement speed and wrinkles
        self.shirt, self.pants, self.hat = None, None, None
        self.hair = None
        self.motion = 0 #alternates between 0 and 1 when moving

    def moveEzzy(self, new_x, new_y):
        self.xfactor = (new_x - self.x)/10
        self.yfactor = (new_y - self.y)/10

    def changeMood(self):
        if self.happiness <= 75 and self.happiness > 50:
            self.moodindex = 0
        elif self.happiness <= 50 and self.happiness > 25:
            self.moodindex = 1
        elif self.happiness <= 25 and self.happiness > 0:
            self.moodindex = 2
    
    def drawEzzy(self, canvas):
        self.image = PhotoImage(file="%s" % (self.moods[self.moodindex][self.motion]))
        canvas.create_image(self.x, self.y, image = self.image)
        
    def personality(self, charac = None):
        self.personalities = ["Kind", "Mean-spirited", "Lazy", "Adventerous",
                              "Ambitious", "Easily Excited",
                              "Not Easily Excited", "Sociable", "Rebellious",
                              "Absent-minded", "Basic", "Optimistic", "Creepy"]

class Personalities(object):
    def __init__(self):
        self.randVal = None
        self.control = 100

    ##Carry out actions based on what randVal is##

class basicP(Personalities):
    
    def __init__(self):
        self.super(basicP, self).__init__()
        self.dialogues = ["Where's my PSL?", "Let's go shopping!",
                        "Which Instagram filter should I choose?", "Carbs? Ew, no.",
                        "My best friend's name is Becca", "OMG, is that Ryan Gosling?!"]
        self.dialogueIndex = None
        
    def selectDialogue(self):
        self.index = random.random(0, len(self.dialogue)-1)
        self.dialogue = self.dialogues[self.index]

class kindP(Personalities):
    
    def __init__(self):
        self.super(kindP, self).__init__()
        self.dialogues = ["You look very nice today", "How is YOUR day doing?",
                          "You're my best friend"]
        self.happiness = 100 #Always *should be unphased by decreasing happiness
        self.appeal = "high"

        
    def selectDialogue(self):
        self.index = random.random(0, len(self.dialogue)-1)
        self.dialogue = self.dialogues[self.index]

class meanP(Personalities):
    
    def __init__(self):
        self.super(meanP, self).__init__()
        self.dialogues = ["You're ugly", "Your shoes look funny",
                          "Your face makes me mad", "I don't wanna"]
        self.appeal = "low"

    def selectDialogue(self):
            self.index = random.random(0, len(self.dialogue)-1)
            self.dialogue = self.dialogues[self.index]
            
class lazyP(Personalities):

    def __init__(self):
        self.super(lazyP, self).__init__()
        self.dialogues = ["I don't feel like it", "You can't make me",
                          "How about you do it instead?",
                          "My best friend's name is Garfield"]

    def selectDialogue(self):
        self.index = random.random(0, len(self.dialogue)-1)
        self.dialogue = self.dialogues[self.index]

class adventerousP(Personalities):
    
    def __init__(self):
        self.super(adventerousP, self).__init__()
        self.dialogues = ["Let's do something today!", "How about that nature?",
                          "Let's go!", "Go Do!"]
        self.wander = False

    def selectDialogue(self):
        self.index = random.random(0, len(self.dialogue)-1)
        self.dialogue = self.dialogues[self.index]

    def Wander(self):
        #wanders somewhere off screen for a given amount of time
        pass

class ambitiousP(Personalities):

    def __init__(self):
        self.super(ambitiousP, self).__init__()
        self.dialogues = ["I wanna be the very best",
                          "Can't is not in my vocabulary",
                          "That sounds awesome!"]
        self.appeal = "high"

    def selectDialogue(self):
        self.index = random.random(0, len(self.dialogue)-1)
        self.dialogue = self.dialogues[self.index]


game = runGame()
game.run()
